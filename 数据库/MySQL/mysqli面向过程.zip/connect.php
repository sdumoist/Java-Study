<?php
//设置页面html编码字符集
header('Content-type:text/html;charset=utf-8');
$host = 'localhost';
$username = 'root';
$password = 'root';
$dbname = 'demo';
$conn = mysqli_connect($host,$username,$password,$dbname);

if (mysqli_connect_errno($conn)) {
    die('<h2 style="color:red">连接失败</h2>'.mysqli_connect_error($conn));
}
//设置客户端字符集
mysqli_set_charset($conn,'utf8');