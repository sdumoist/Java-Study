<?php
header('content-type:text/html;charset=utf-8');
echo '<h2 style="color:orangered">MySQLi面向过程入门教程</h2>';
