<?php
require 'connect.php';  //连接数据库

$sql = "UPDATE `student` SET `course`='javascript', `grade`=88 WHERE `id`=3";

if (mysqli_query($conn, $sql)){
    echo '成功更新了'.mysqli_affected_rows($conn).'条记录';
} else {
    echo '更新失败'.mysqli_error($conn);
}

mysqli_close($conn);