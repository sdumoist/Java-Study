<?php
require  'connect.php'; //连接数据库

//执行查询
$sql = "SELECT `id`,`name`,`course`,`grade` FROM `student` WHERE `id`>1 ";

//获取结果集
$result = mysqli_query($conn,$sql);

if ($result && mysqli_num_rows($result) >0) {

    echo '当前字段的索引是:'.mysqli_field_tell($result);
    $field = mysqli_fetch_field($result);
    echo '<pre>';
    print_r($field);
    echo '当前字段的name属性是:'.$field->name;
    echo '下一个字段的索引是:'.mysqli_field_tell($result);
    echo '<hr>';
    echo '当前字段的索引是:'.mysqli_field_tell($result);
    $field = mysqli_fetch_field($result);
    echo '<pre>';
    print_r($field);
    echo '当前字段的name属性是:'.$field->name;
    echo '下一个字段的索引是:'.mysqli_field_tell($result);

}

mysqli_field_seek($result,0);//字段列表指针复位
//用循环遍历字段信息
echo '<hr color="red">';
echo '循环遍历字段信息';
if ($result && mysqli_num_rows($result) >0) {
    while ($field = mysqli_fetch_field($result)){
        echo '<pre>';
        print_r($field);
        echo '当前字段的name属性是:'.$field->name;
        echo '下一个字段的索引是:'.mysqli_field_tell($result);
    }
}



//释放结果集
mysqli_free_result($result);

//关闭连接
mysqli_close($conn);