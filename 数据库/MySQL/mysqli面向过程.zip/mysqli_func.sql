-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `grade` int(5) NOT NULL,
  `create_time` int(10) NOT NULL,
  `update_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `student` (`id`, `name`, `course`, `grade`, `create_time`, `update_time`) VALUES
(1,	'郭靖',	'php',	90,	0,	0),
(2,	'黄蓉',	'mysql',	80,	0,	0),
(3,	'洪七',	'javascript',	88,	0,	0),
(4,	'老顽童',	'php',	50,	0,	0),
(5,	'欧阳峰',	'mysql',	68,	0,	0),
(6,	'杨康',	'javascript',	90,	0,	0),
(7,	'杨铁心',	'php',	78,	0,	0);

-- 2017-09-12 15:03:37